const allowedOrigins = [
    'http://localhost:3000',
    'https://busbookingusdt.xyz',
    'https://www.busbookingusdt.xyz'
]

module.exports = allowedOrigins